import tkinter as tk
from math import sqrt, factorial


def on_click(button_value):
    current_text = entry_var.get()

    if button_value == "=":
        try:
            result = eval(current_text)
            entry_var.set(result)
        except Exception as e:
            entry_var.set("Error")
    elif button_value == "C":
        entry_var.set("")
    elif button_value == "√":
        entry_var.set(sqrt(float(current_text)))
    elif button_value == "<_":
        entry_var.set(current_text + "<=")
    elif button_value == "!":
        try:
            result = factorial(int(current_text))
            entry_var.set(result)
        except ValueError:
            entry_var.set("Error")
    else:
        entry_var.set(current_text + str(button_value))


root = tk.Tk()
root.title("Calculator")
root.geometry("300x400")
root.configure(bg="white")

entry_var = tk.StringVar()
entry = tk.Entry(root, textvariable=entry_var, font=('Arial', 18), justify='right', bd=10, bg="white")
entry.grid(row=0, column=0, columnspan=4, ipady=10)

buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+',
    '√', '<_', '!', 'C',
]

row_val = 1
col_val = 0

for button in buttons:
    tk.Button(root, text=button, width=3, height=2, font=('Arial', 12), command=lambda b=button: on_click(b),
              bg="white").grid(row=row_val, column=col_val, padx=5, pady=5)
    col_val += 1
    if col_val > 3:
        col_val = 0
        row_val += 1

root.mainloop()