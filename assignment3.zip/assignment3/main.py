import tkinter as tk
import string
import random

def generate_password(length):
    characters = string.ascii_letters + string.digits + string.punctuation
    generated_password = ''.join(random.choice(characters) for _ in range(length))
    return generated_password

def on_generate():
    password_length = int(length_var.get())
    generated_password = generate_password(password_length)
    password_entry.delete(0, tk.END)
    password_entry.insert(0, generated_password)
    password_entry.config(fg="green")

def on_accept():
    username = username_entry.get()
    password = password_entry.get()
    result_text.set(f"Username: {username}\nPassword: {password}")

def on_reset():
    username_entry.delete(0, tk.END)
    length_var.set("")
    password_entry.delete(0, tk.END)
    result_text.set("")
    password_entry.config(fg="black")

root = tk.Tk()
root.title("Password Generator")

heading_label = tk.Label(root, text="Password Generator", font=('Arial', 16, 'underline', 'bold'), fg="dark blue")
heading_label.grid(row=0, column=0, columnspan=3, pady=10)

tk.Label(root, text="Enter username:").grid(row=1, column=0, padx=10, pady=5)
username_entry = tk.Entry(root, bd=4, relief="ridge")
username_entry.grid(row=1, column=1, columnspan=2, padx=10, pady=5)

tk.Label(root, text="Enter password length:").grid(row=2, column=0, padx=10, pady=5)
length_var = tk.StringVar()
length_entry = tk.Entry(root, textvariable=length_var, bd=4, relief="ridge")
length_entry.grid(row=2, column=1, columnspan=2, padx=10, pady=5)

tk.Label(root, text="Generated Password:").grid(row=3, column=0, padx=10, pady=5)
password_entry = tk.Entry(root, font=('Arial', 12), bd=4, relief="ridge")
password_entry.grid(row=3, column=1, columnspan=2, padx=10, pady=5)

generate_button = tk.Button(root, text="Generate Password", command=on_generate, bd=4, relief="ridge", bg="dark blue", fg="white", font=('Arial', 12, 'bold'))
generate_button.grid(row=4, column=0, columnspan=3, padx=10, pady=10)

accept_button = tk.Button(root, text="Accept", command=on_accept, bd=4, relief="ridge", fg="blue")
accept_button.grid(row=5, column=1, pady=10, padx=10)

reset_button = tk.Button(root, text="Reset", command=on_reset, bd=4, relief="ridge", fg="blue")
reset_button.grid(row=6, column=1, pady=10, padx=10)

result_text = tk.StringVar()
result_label = tk.Label(root, textvariable=result_text, font=('Arial', 12), fg="green")
result_label.grid(row=7, column=0, columnspan=3, padx=10, pady=5)

# Run the Tkinter event loop 
root.mainloop()
