import requests

def get_weather_data(user_input):
    api_key = '934735af6ccd463335ec5f4e46f3c785'
    base_url = 'https://api.openweathermap.org/data/2.5/weather'

    params = {'q': user_input, 'appid': api_key, 'units': 'metric'}
    response = requests.get(base_url, params=params)
    weather_data = response.json()

    return response, weather_data

def display_weather(response, weather_data):
    if response.status_code == 200:
        temperature = weather_data['main']['temp']
        humidity = weather_data['main']['humidity']
        description = weather_data['weather'][0]['description']

        print(f"Weather in {user_input}:")
        print(f"Temperature: {temperature}°C")
        print(f"Humidity: {humidity}%")
        print(f"Description: {description}")
    else:
        print(f"Error: {weather_data['message']}")

if __name__ == "__main__":
    user_input = input("Enter the name of a city or a zip code: ")

    
    response, weather_data = get_weather_data(user_input)

    display_weather(response, weather_data)
